package com.javainfinite.jwt.example.service;

import com.javainfinite.jwt.example.model.Manager;
import com.javainfinite.jwt.example.repository.ManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManagerService {

    @Autowired
    private ManagerRepository repository;


    public Manager save(Manager manager) {
       return repository.save(manager);
    }

    public List<Manager> getAll() {
        return repository.findAll();
    }


}
